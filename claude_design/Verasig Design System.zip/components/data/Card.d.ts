import { ReactNode, HTMLAttributes } from 'react';

/**
 * Surface container — the base card used across the app. Optional header
 * (title/subtitle/actions) and footer. Use `interactive` for clickable cards
 * and `glow` to highlight a live/active state.
 */
export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  /** Header title. */
  title?: string;
  /** Header subtitle. */
  subtitle?: string;
  /** Right-aligned header actions (buttons, badges). */
  headerActions?: ReactNode;
  /** Footer node. */
  footer?: ReactNode;
  /** Apply default body padding. @default true */
  padded?: boolean;
  /** Hover lift + pointer cursor. @default false */
  interactive?: boolean;
  /** Signal glow border (live/active). @default false */
  glow?: boolean;
  children?: ReactNode;
}

export function Card(props: CardProps): JSX.Element;
